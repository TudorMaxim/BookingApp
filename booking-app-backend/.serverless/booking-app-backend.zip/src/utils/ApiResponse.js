"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var response = function (_a) {
    var status = _a.status, body = _a.body, headers = _a.headers;
    return ({
        statusCode: status,
        body: JSON.stringify(body, null, 2),
        headers: headers
    });
};
var api = {
    response: response
};
exports.default = api;
//# sourceMappingURL=ApiResponse.js.map